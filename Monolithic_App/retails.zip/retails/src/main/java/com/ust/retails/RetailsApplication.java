package com.ust.retails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RetailsApplication.class, args);
	}

}
