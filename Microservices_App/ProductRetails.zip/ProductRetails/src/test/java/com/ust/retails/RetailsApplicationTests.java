package com.ust.retails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
